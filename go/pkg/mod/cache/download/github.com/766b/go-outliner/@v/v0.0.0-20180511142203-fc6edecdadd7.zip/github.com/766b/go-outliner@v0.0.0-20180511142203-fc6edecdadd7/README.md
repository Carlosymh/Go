# Go-Outliner

## Install

    go get -u github.com/766b/go-outliner

## Usage

    go-outliner ./path/to/go/files