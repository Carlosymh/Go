package main

var Variable01Int int

const Const01String string = ""

var Variable02String string
